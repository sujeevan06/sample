<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Jobs\TestJob;

class TestController extends Controller
{
    public function addJob()
    {
		// Script start
		$rustart = getrusage();

		$i = 0;
		while ($i++ < 100)
			dispatch(new TestJob());

		// Script end
		function rutime($ru, $rus, $index) {
		return ($ru["ru_$index.tv_sec"]*1000 + intval($ru["ru_$index.tv_usec"]/1000))
		-  ($rus["ru_$index.tv_sec"]*1000 + intval($rus["ru_$index.tv_usec"]/1000));
		}

		$ru = getrusage();
		echo "This process used " . rutime($ru, $rustart, "utime") .
		" ms for its computations\n";
		echo "It spent " . rutime($ru, $rustart, "stime") .
		" ms in system calls\n";
    }
}
