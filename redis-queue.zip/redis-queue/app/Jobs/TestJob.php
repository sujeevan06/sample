<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use App\User;
use Illuminate\Support\Str;
use Faker\Generator as Faker;

class TestJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct()
    {
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        echo "start processing job...\r\n";
        // sleep(0.1);
        // $user = new User();
        // $user->name = 'niroshan';
        // $user->email = 'niroshanjwm' . microtime() . '@gmail.com';
        // $user->password = 'test@123';
        // $user->save();
        echo "end processing job...\r\n";
    }
}
